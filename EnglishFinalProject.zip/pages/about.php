<!DOCTYPE html>
<html>

    <head>
        
        <title>English Project - About</title>
        <link rel="icon" href="source/favicon.ico">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style/style.css">
        <script src="script/source.js"></script>

    </head>

    <body>

        <div class="topnav" class="disable-select">

            <a href="index.php">Home</a>
            <a href="pageone.php">Project</a>
            <a class="active" href="about.php">About</a>

        </div>

        <div class="center disable-select" style="padding-left:16px; padding-right:16px;">

            <h1>About</h1>
            <p>
              
              Info: My 2022 English Project.
              </br>
              About: Who is to blame for the 
              tradegy in the book Of Mice And Men.
              </br>
              By: Trent Weikel
              
            </p>

        </div>

    </body>

</html>